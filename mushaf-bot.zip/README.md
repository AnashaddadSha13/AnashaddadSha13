## Mushaf Bot Discord v1
- بوت يحتوي علي أكتر من 5أنواع لمصحف
- يوجد ازرار لتحكم في تقليب بين الصفحات الخاصة بالمصحف
- يمكن لشخص ان يقوم بحفظ صفحة في مصحف نوع معين حيث ان عند اعاداة استخدام الامر سوف يقوم بجلب المصحف بالصفحةا لمحفوظة لديه
- يمكننك من خلال البوت عمل رسالة ثابته في روم حيث ناس من خلاله ضغط علي زر برسالة وسوف يقوم بفتح مصحف خاص بشخص
- بوت في الخير اتمنه تنشره وشكراً لكم

## Contact
**Any bug or suggestion !**
 - Contact With Me Discord: [`Shuruhatik#2443`](https://github.com/shuruhatik)
### Server Support
<a href="https://dsc.gg/shuruhatik"><img src="https://invidget.switchblade.xyz/uGu2sCDZhv"></a>

## License 
- [ BSL-1.0 License](./LICENSE)